(function(window,document){}).call(this,this,this.document);
